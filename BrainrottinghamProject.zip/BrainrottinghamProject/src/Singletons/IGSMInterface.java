package Singletons;

public interface IGSMInterface {

}
