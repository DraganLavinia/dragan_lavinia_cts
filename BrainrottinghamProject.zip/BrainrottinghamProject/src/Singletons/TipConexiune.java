package Singletons;

public enum TipConexiune {

    URGENTE, PRIORITARE, NORMALE
}
